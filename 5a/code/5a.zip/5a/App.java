
import java.util.*;

/**
 * @author Daniela Cano
 */
public class App {

    /**
     * Default constructor
     */
    public App() {
    }

    /**
     * @param argv
     */
    public static void main(String[] argv) {
        // TODO implement here
        // Se crea una instancia de la clase Logic3a
	Logic5a myLogic4a = new Logic5a();//UUU
	System.out.println("4a project");//UUU
    // Se llama el metodo logic3a para ejecutar el programa
	myLogic4a.logic5a();//UUU

    }

}